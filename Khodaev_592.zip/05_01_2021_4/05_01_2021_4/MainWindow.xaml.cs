﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace _05_01_2021_4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            _possibleAnswers = new string[5]
            {
                "да",
                "Возможно нет",
                "Нет",
                "Никак нет",
                "Возможно да"
            };
            _answers = new Dictionary<string, string>();
           
            InitializeComponent();
        }
        private Dictionary<string, string> _answers;
        private string[] _possibleAnswers;
        private void Answer_Click(object sender, RoutedEventArgs e)
        {
            Random rnd = new Random();
            string question = txtQuestion.Text;
            if (!_answers.ContainsKey(question))
                _answers[question] = _possibleAnswers[rnd.Next(1, 5)];           
            txtAnswer.Text = _answers[question];
        }
        private void txtQuestion_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}


